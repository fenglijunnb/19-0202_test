@foreach($arr as $k=>$v)
    <tr id="{{$v->id}}">
        <td>{{$v->id}}</td>
        <td class="change" column="name" value="{{$v->name}}">{{$v->name}}</td>
        <td>{{$v->c_name}}</td>
        <td>{{$v->desc}}</td>
        <td>
            <?php if($v->is_hot==1){ ?>
            <input type="button"  value="√" id="{{$v->id}}" class="is_hot">
            <?php }else if($v->is_hot==2){ ?>
            <input type="button"  value="×"  id="{{$v->id}}" class="is_hot">
            <?php } ?>
        </td>
        <td>
            <?php if($v->is_show==1){ ?>
            <input type="button"  value="√" id="{{$v->id}}" class="is_show">
            <?php }else if($v->is_show==2){ ?>
            <input type="button"  value="×"  id="{{$v->id}}" class="is_show">
            <?php } ?>
        </td>
        <td>
            <a href="update?id={{$v->id}}">修改</a>
            <a href="javascript:;" name="del"   id="{{$v->id}}">删除</a>
        </td>
    </tr>
@endforeach
<tr>
    <td colspan="7"><div id="page">{{ $arr->links() }}</div></td>
</tr>
<script>
    $("[name='del']").click(function(){
        var _this=$(this);
        var goods_id=_this.attr('id');
        if(confirm('是否删除？')){
            $.post('delete',{id:goods_id},function(res){
                if(res==1){
                    _this.parents('tr').remove();
                    alert('删除成功');
                }else{
                    alert('删除失败');
                }
            });
        }
    });
</script>