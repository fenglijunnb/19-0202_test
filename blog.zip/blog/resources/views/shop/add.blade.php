<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src="/js/jquery-3.1.1.min.js"></script>
</head>
<body>
<form class="add_form">
    <table border="1">
        <tr>
            <td>名称</td>
            <td><input type="text" name="name"></td>
        </tr>
        <tr>
            <td>分类</td>
            <td><select name="c_id">
                    <option value="0">请选择</option>
                    <?php foreach($cate as $k=>$v){?>
                    <option value="{{$v->c_id}}">{{$v->c_name}}</option>
                    <?php  } ?>
                </select></td>
        </tr>
        <tr>
            <td>描述</td>
            <td><textarea name="desc"></textarea></td>
        </tr>
        <tr>
            <td>是否热卖</td>
            <td><input type="radio" name="is_hot" value="1" checked>热卖
                <input type="radio" name="is_hot" value="2">淡季
            </td>
        </tr>
        <tr>
            <td>是否上架</td>
            <td><input type="radio" name="is_show" value="1" checked>上架
                <input type="radio" name="is_show" value="2">下架
            </td>
        </tr>
        <tr>
            <td colspan="2"><input type="button" class="submit" value="提交"> </td>
        </tr>
    </table>
</form>
</body>
</html>
<script>
    $(function(){
        $('.submit').click(function(){
            var form=$(".add_form").serialize();
            $.ajax({
                url:'doadd',
                data:form,
                method:'post',}).done(function (res) {
                if(res==1){
                    alert('添加成功');
                    location.href='show';
                }else{
                    alert('添加失败');
                    location.href='add';
                }
            })
        });
    })
</script>