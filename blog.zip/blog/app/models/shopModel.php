<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class shopModel extends Model
{
    protected $table = 'shop';
    public $timestamps = false;
}
