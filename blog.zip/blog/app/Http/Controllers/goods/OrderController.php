<?php

namespace App\Http\Controllers\goods;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\models\CartModel;

class OrderController extends Controller
{
    /**
     * 提交结算
     * @param Request $request
     */
   public function payment(Request $request){
       $user_id=session('u_id');
       if(empty($user_id)){
           echo "<script>alert('请先登录！');location.href='login?href='+location.href</script>";die;
       }
        $data=$request->input('data');
//       dump($data);die;
       if($data!=null){
           $cart=CartModel::whereIn('cart_id',$data)->join('goods','goods.goods_id','=','cart.goods_id')->select('*')->get()->toArray();
//           dump($cart);die;
           foreach ($cart as $k=>$v){
               if($v['buy_num']>$v['goods_pnum']){
                   $all[]=$v['goods_name'];
               }
               $goodsIds[]=$v['goods_id'];
           }
           if(!empty($all)){
               echo json_encode(['code'=>0,'msg'=>implode(',',$all).'----这些商品的库存不足,请先减少购买数量']);
               die;
           }
           foreach($cart as $k=>$v){
               if($v['goods_show']!=1){
                   $add[]=$v['goods_name'];
               }
               //        总金额
               $money[]=$v['goods_price']*$v['buy_num'];
           }
           if(!empty($add)){
               echo json_encode(['code'=>0,'msg'=>'对不起，'.implode(',',$add).'----这些商品的已下架,请删除这些商品']);
               die;
           }
       }else{
           echo json_encode(['code'=>0,'msg'=>'请选择一件商品！']);
           die;
       }
        //        订单号
        $order_sn=date("YmdHis",time()).rand(1000,9999);
//        print_r($order_sn);die;
        //        添加进库
           $array=[
               'order_sn'=>$order_sn,
               'user_id'=>$user_id,
               'order_status'=>1,
               'order_amount'=>array_sum($money),
               'add_time'=>time(),
               'pay_status'=>1,
               'order_pay_type'=>1,
               'pay_id'=>1,
           ];
           $res=DB::table('order_info')->insertGetId($array);
           if(!empty($res)){
               DB::table('cart')->whereIn('cart_id',$data)->update(['status'=>0]);
               foreach ($cart as $k=>$v){
                   $arr[]=[
                       'order_id'=>$res,
                       'goods_id'=>$v['goods_id'],
                       'goods_name'=>$v['goods_name'],
                       'order_sn'=>$order_sn,
                       'user_id'=>$user_id,
                       'buy_number'=>$v['buy_num'],
                       'shop_price'=>$v['goods_price']
                   ];
               }
               $arr=DB::table('order_goods')->insert($arr);
               echo json_encode(['code'=>1,'msg'=>'添加成功','order_id'=>$res]);
           }else{
               echo json_encode(['code'=>0,'msg'=>'添加失败','order_id'=>'']);
           }
   }

    /**
     * 订单页面的展示
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View|\think\response\View
     */
   public function order(Request $request){
       $order_id=$request->input('order_id');
       $user_id=$user_id=$request->session()->get('u_id');
       if(empty($user_id)){
           echo "<script>alert('请先登录！');location.href='login?href='+location.href</script>";die;
       }
       $where=[
           'order_id'=>$order_id,
           'user_id'=>$user_id
       ];
       $arr=DB::table('order_goods')->where($where)->get()->toArray();
//       dump($arr);
       $order_price=DB::table('order_info')->where($where)->get()->toArray()[0];
//       dump($order_price);die;
       return view("order.payment",['arr'=>$arr,'order_price'=>$order_price]);
   }

    /**
     * 订单验证页面
     * @param Request $request
     */
   public function order_do(Request $request){
       $order_id=$request->input('order_id');
//       print_r($order_id);
       $user_id=$user_id=$request->session()->get('u_id');
       if(empty($user_id)){
           echo "<script>alert('请先登录！');location.href='login?href='+location.href</script>";die;
       }
       $where=[
           'user_id'=>$user_id,
           'order_id'=>$order_id,
           'is_del'=>0
       ];
//       dump($where);
       $arr=DB::table('user_address')->where($where)->value('address_id');
//       dump($arr);die;
       if(!empty($arr)){
            echo json_encode(['code'=>1,'msg'=>'准备支付']);
       }else{
           echo json_encode(['code'=>0,'msg'=>'没有详细地址，请填写详细地址','order_id'=>$order_id]);
       }
   }

    /**
     * 详细地址展示
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View|\think\response\View
     */
   public function address(Request $request){
       $order_id=$request->input('order_id');
       $user_id=$user_id=$request->session()->get('u_id');
//       print_r($user_id);die;
       if(empty($user_id)){
           echo "<script>alert('请先登录！');location.href='login?href='+location.href</script>";die;
       }
       $arr=DB::table('user_address')->join('user','user.user_id','=','user_address.user_id')->where('user_address.user_id',$user_id)->where('is_del',0)->get();
//       dump($arr);
       return view('order.address',['arr'=>$arr,'order_id'=>$order_id]);
   }
    /**
     * 添加地址页面
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View|\think\response\View
     */
   public function writeaddress(Request $request){
       $order_id=$request->input('order_id');
       return view('order.writeaddress',['order_id'=>$order_id]);
    }

    /**
     *添加地址
     * @param Request $request
     */
    public function address_do(Request $request){
        $data=$request->input();
//        dump($data);die;
        $order_id=$data['order_id'];
        $is_default=$data['is_default'];
//        dump($is_default);die;
        $user_id=$user_id=$request->session()->get('u_id');
        if(empty($user_id)){
            echo "<script>alert('请先登录！');location.href='login?href='+location.href</script>";die;
        }
        $data['user_id']=$user_id;
        $data['is_del']=0;
        if($is_default==1){
            $res=DB::table('user_address')->where('user_id',$user_id)->where('is_default',$is_default)->update(['is_default'=>0]);
        }
        $res=DB::table('user_address')->insert($data);
//        echo $res;die;
        $address_id=DB::table('user_address')->where('order_id',$order_id)->value('address_id');
//        echo $address_id;die;
        if(!empty($order_id)){
            $arr=DB::table('order_info')->where('order_id',$order_id)->update(['address_id'=>$address_id]);
        }
        if($res){
            echo json_encode(['code'=>1,'msg'=>'添加成功']);
        }else{
            echo json_encode(['code'=>0,'msg'=>'添加失败']);
        }
    }
    //删除地址
    public function  add_del(Request $request){
        $address_id=$request->input('address_id');
        $all=DB::table('user_address')->where('address_id',$address_id)->get()->toArray()[0];
//        dump($all);die;
        if($all->is_default==1){
            return json_encode([
                'code'=>0,
                'msg'=>'请先修改默认地址，再次删除'
            ]);
        }
        $res=DB::table('user_address')->where('address_id',$address_id)->update(['is_del'=>1]);
        if($res){
            return json_encode([
                'code'=>1,
                'msg'=>'删除成功'
            ]);
        }else{
            return json_encode([
                'code'=>0,
                'msg'=>'删除失败'
            ]);
        }
    }
    //修改地址
    public function add_update(Request $request){
        $address_id=$request->input('address_id');
        dump($address_id);
        $user_id = $user_id = $request->session()->get('u_id');
        $res=DB::table('user_address')->where('address_id','!=',$address_id)->where('user_id',$user_id)->update(['is_default'=>0]);
        $add=DB::table('user_address')->where('address_id','=',$address_id)->where('user_id',$user_id)->update(['is_default'=>1]);
    }
    //编辑修改
    public function address_update(Request $request){
        $address_id=$request->input('address_id');
//        dump($address_id);
        $address=DB::table('user_address')->where('address_id',$address_id)->get()->toArray();
//        dump($address);die;
        return view("order.address_update",['address'=>$address]);
    }
    //编辑修改执行
    public function add_update_do(Request $request){
        $data=$request->input('data');
//        dump($data);die;
        $res=DB::table('user_address')->where('address_id',$data['address_id'])->update($data);
        if($res){
            return json_encode([
                'code'=>1,
                'msg'=>'保存成功'
            ]);
        }else{
            return json_encode([
                'code'=>0,
                'msg'=>'保存失败'
            ]);
        }
    }
}
