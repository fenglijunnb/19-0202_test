<?php

namespace App\Http\Controllers\goods;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class GoodsController extends Controller
{
    /**
     * 商品详情
     */
   public function detail(Request $request){
       $goods_id=$request->input('goods_id');
       $arr=DB::table('goods')->where('goods_id',$goods_id)->get();
//       print_r($arr);die;
       $user_id=$request->session()->get('u_id');
//        print_r($goods_id);die;
       if(!empty($user_id)){
                $number=DB::table('cart')->where('user_id',$user_id)->where('status',1)->select('buy_num')->get();
               $num=[];
               foreach($number as $k=>$v){
                   $num[]=$v->buy_num;
               }
               $count=array_sum($num);
       }else{
           $count=0;
       }
        return view('goods.shopcontent',['arr'=>$arr,'count'=>$count]);
   }
    /**
     * 购物车列表
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View|\think\response\View
     */
    public function shopcart(Request $request)
    {
        $goods_id = $request->input('goods_id');
        $user_id = $request->session()->get('u_id');
//        print_r($goods_id);die;
        if (!empty($goods_id)) {
            if (empty($user_id)) {
                return $info = [
                    'status' => 0,
                    'msg' => '请登录后进行此操作'
                ];
            } else {
                $goods = DB::table('goods')->where(['goods_show' => 1, 'goods_id' => $goods_id])->first();
//                print_r($goods);
                $goods_number = $goods->goods_pnum;
                if (empty($goods)) {
                    return $info = [
                        'status' => 0,
                        'msg' => '该商品已下架'
                    ];
                } else if ($goods_number == 0) {
                    return $info = [
                        'status' => 0,
                        'msg' => '该商品已经没有库存'
                    ];
                } else {
                    $buy_goods = DB::table('cart')->where(['user_id' => $user_id, 'goods_id' => $goods_id,'status'=>1])->first();
                    if (!empty($buy_goods)) {
                        $arr = [
                            'buy_num' => $buy_goods->buy_num + 1,
                            'create_time' => time(),
                        ];
                        $res = DB::table('cart')->where(['user_id' => $user_id, 'goods_id' => $goods_id])->update($arr);
                        if ($res) {
                            return $info = [
                                'status' => 1,
                                'msg' => '商品已经成功加至购物车'
                            ];
                        } else {
                            return $info = [
                                'status' => 0,
                                'msg' => '操作失败，请重试'
                            ];
                        }
                    } else {
                        $arr = [
                            'goods_id' => $goods_id,
                            'user_id' => $user_id,
                            'status' => 1,
                            'buy_num' => 1,
                            'create_time' => time(),
                        ];
                        $res = DB::table('cart')->insert($arr);
                        if ($res) {
                            return $info = [
                                'status' => 1,
                                'msg' => '商品已经成功加至购物车'
                            ];
                        } else {
                            return $info = [
                                'status' => 0,
                                'msg' => '操作失败，请重试'
                            ];
                        }
                    }

                }
            }
        }
    }

    /**
     * 购物车展示
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View|\think\response\View
     */
    public function cart(){
        $user_id=session('u_id');
        if(empty($user_id)){
            echo "<script>alert('请先登录！');location.href='login?href='+location.href</script>";die;
        }
        $data=DB::table('cart')->join('goods','goods.goods_id','=','cart.goods_id')->where('status',1)->select("*")->get();
        $goods_info=DB::table('goods')->where('goods_hot',1)->limit(4)->select('goods_img','goods_price','goods_name','goods_id')->get();
        return view('goods.shopcart',['data'=>$data,'goods_info'=>$goods_info]);
    }

    /**
     * 购物车的删除
     * @param Request $request
     */
    public function cart_del(Request $request){
            $data=$request->input('data');
//            print_r($data);
            if(!empty($data)){
                foreach($data as $k=>$v){
                    $res=DB::table('cart')->where(['cart_id'=>$v])->update(['status'=>2]);
                }
                if($res){
                    echo json_encode(['code'=>1,'msg'=>'删除成功！']);
                }else{
                    echo json_encode(['code'=>1,'msg'=>'删除失败！']);
                }
            }else{
                echo json_encode(['code'=>0,'msg'=>'请选择商品！']);
            }
    }

    /**
     * 加减改变商品数量
     * @param Request $request
     */
    public function updateNum(Request $request){
        $data=$request->input();
        $cart_id=$data['cart_id'];
        $num=$data['num'];
        $res=DB::table('cart')->where('cart_id','=',$cart_id)->update(['buy_num'=>$num]);
    }

}
