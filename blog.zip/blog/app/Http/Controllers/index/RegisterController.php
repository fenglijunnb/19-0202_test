<?php

namespace App\Http\Controllers\index;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\models\User;

class RegisterController extends Controller
{
    /**
     * 注册展示页面
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View|\think\response\View
     */
    public function register(){
        return view('index.register');
    }

    /**
     * 注册执行页面
     * @param Request $request
     */
    public function register_do(Request $request){
        $arr=$request->input();
        $tel=$arr['tel'];
        $pwd=$arr['pwd'];
        $code=$arr['userCode'];
        $conpwd=$arr['conpwd'];
        //验证密码
        if($pwd!=$conpwd){
//            echo 1111;
            $arr=array(
                'code'=>0,
                'msg'=>'俩次密码不一致'
            );
            echo json_encode($arr);
        }
        //验证 唯一
        $name=User::where('name',$tel)->first();
        if(!empty($name)&&!empty($name['pwd'])){
            $arr=array(
                'code'=>0,
                'msg'=>'手机号已经存在'
            );
            echo json_encode($arr);
        }
        //验证验证码
        $code_info=DB::table('code')->where('tel',$tel)->where('status',1)->orderBy('c_id','desc')->first();
        if(empty($code_info)){
            echo json_encode(['code'=>0,'msg'=>'请输入收取验证码的手机号！']);die;
        }
        if(time()>$code_info->timeout){
            echo json_encode(['code'=>0,'msg'=>'您的验证码过期！']);die;
        }
        if($code!=$code_info->code){
            echo json_encode(['code'=>0,'msg'=>'您的验证码有误！']);die;
        }
        $pwd=md5($pwd);
       $arrInfo=array(
           'name'=>$tel,
           'pwd'=>$pwd
       );
       $res=DB::table('user')->insert($arrInfo);
       if($res){
           $arr=array(
               'code'=>1,
               'msg'=>'注册成功'
           );
           echo json_encode($arr);
           $id=$code_info->c_id;
           DB::table('code')->where('c_id',$id)->update(['status'=>0]);
       }else{
           $arr=array(
               'code'=>0,
               'msg'=>'注册失败'
           );
           echo json_encode($arr);
       }
    }

    /**
     * 登录页面
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View|\think\response\View
     */
    public function login(){
        return view('index.login');
    }

    /**
     * 登录执行页面
     * @param Request $request
     */
    public function login_do(Request $request){
        $arr=$request->input();
        $tel=$arr['tel'];
        $pwd=$arr['pwd'];
        $pwd=md5($pwd);
        $where=[
            'name'=>$tel,
            'pwd'=>$pwd
            ];
        $data=DB::table('user')->where($where)->first();
        if(empty($pwd)||empty($tel)){
            $arr=array(
                'code'=>0,
                'msg'=>'参数错误'
            );
            echo json_encode($arr);
        }
        if($data){
            $id=$data->user_id;
            $name=$data->name;
            session(['u_id'=>$id,'name'=>$name]);
            $arr=array(
                'code'=>1,
                'msg'=>'登录成功'
            );
            echo json_encode($arr);
        }else{
            $arr=array(
                'code'=>0,
                'msg'=>'账号或密码错误'
            );
            echo json_encode($arr);
        }
    }

    /**
     * 发送短信的方法
     * @param Request $request
     */
    public function send(Request $request){
        $arr=$request->input();
        $num = rand(1000,9999);
//        dump($arr);exit;
        $tel=$arr['tel'];
        $obj=new \send();
        $code=$obj->show($tel,$num);
//        print_r($code);die;
        if($code==100){
            $data=[
                'code'=>$num,
                'tel'=>$tel,
                'status'=>1,
                'timeout'=>time()+60*60
            ];
            $res=DB::table('code')->insert($data);
            $arr=array(
                'code'=>1,
                'msg'=>'短信发送成功'
            );
            echo json_encode($arr);
        }else{
            $arr=array(
                'code'=>0,
                'msg'=>'短信发送失败'
            );
            echo json_encode($arr);
        }
    }
}
