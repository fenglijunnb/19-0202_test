<?php

namespace App\Http\Middleware;

use Closure;

class Test
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     *@param  \Closure  $next
* @return mixed
    */
    public function handle($request, Closure $next)
{
    $usersession=$request->session()->get('name');
//        echo $usersession;
//        exit;
    if(empty($usersession)){
        return redirect('login');
//            return false;
    }
//        echo 1111;
    return $next($request);
}
}
